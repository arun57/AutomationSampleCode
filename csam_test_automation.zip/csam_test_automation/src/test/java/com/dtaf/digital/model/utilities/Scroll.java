package com.dtaf.digital.model.utilities;

import com.dtaf.digital.bdd.steps.support.BaseSteps;
import com.dtaf.digital.bdd.steps.support.ObjectContainer;
import com.dtaf.digital.bdd.steps.support.WebBaseSteps;
import com.dtaf.digital.model.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Scroll extends BasePage<Scroll> {

    private static JavascriptExecutor scriptExecutor;

    public Scroll(WebDriver driver){
        super(driver);
    }

    public void scrollToElement(By element) {
        WebElement ele = driver.findElement(element);
        System.out.println("************"+ele.getText());
        scriptExecutor = (JavascriptExecutor) driver;
        scriptExecutor.executeScript("arguments[0].scrollIntoView();", ele);
    }

    public void scrollToBottomOfThePage() {
        scriptExecutor = (JavascriptExecutor) driver;
        scriptExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }


}
