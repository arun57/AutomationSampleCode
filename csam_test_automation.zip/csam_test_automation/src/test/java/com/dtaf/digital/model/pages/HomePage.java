package com.dtaf.digital.model.pages;

import com.dtaf.digital.model.data.LoginData;
import com.dtaf.digital.model.pages.csam.ServiceTypesPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage<HomePage> {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	public ServiceTypesPage gotoMenuServiceType(String input) {
		clickWaffle().inputForSearch(input).clickSearchResult(input);
		return new ServiceTypesPage(driver);
	}

	public EnvironmentsPage gotoMenu(String input) {
		clickWaffle().inputForSearch(input).clickSearchResult(input);
		return new EnvironmentsPage(driver);
	}

	public HomePage clickWaffle(){
		driver.findElement(By.xpath("//*[@class='slds-icon-waffle']")).click();
		return this;
	}

	public HomePage inputForSearch(String input){
		driver.findElement(By.xpath("//input[@placeholder='Search apps and items...']")).sendKeys(input);;
		return this;
	}

	public HomePage clickSearchResult(String input){
		driver.findElement(By.xpath("//*[@class='slds-truncate']/*[text()='"+input+"']")).click();
		return this;
	}

}
