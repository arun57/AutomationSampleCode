package com.dtaf.digital.model.data;

public class LoginData {
    private final String username;
    private final String password;

    public LoginData(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String username() {
        return username;
    }

    public String password() {
        return password;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof LoginData) {
            var o = (LoginData)obj;
            return o.username.equals(username) && o.password.equals(password);
        }
        return false;
    }

    @Override
    public String toString() {
        return "[username:"+username+", password:"+password+"]";
    }
}
