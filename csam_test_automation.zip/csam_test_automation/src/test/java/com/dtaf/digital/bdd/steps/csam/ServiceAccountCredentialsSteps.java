package com.dtaf.digital.bdd.steps.csam;

import com.dtaf.digital.bdd.steps.support.ObjectContainer;
import com.dtaf.digital.bdd.steps.support.WebBaseSteps;
import com.dtaf.digital.model.data.LoginData;
import com.dtaf.digital.model.pages.HomePage;
import com.dtaf.digital.model.pages.csam.CredentialsPage;
import com.dtaf.digital.model.pages.csam.LoginPage;
import com.dtaf.digital.model.pages.csam.ServiceAccountPage;
import com.dtaf.digital.model.utilities.CustomWait;
import com.dtaf.digital.model.utilities.FindElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.bouncycastle.operator.OperatorCreationException;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ServiceAccountCredentialsSteps extends WebBaseSteps {
	protected final Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());
	protected final String serviceAccountName = "AUTOTEST" + DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());
	public static final String EMAIL = "sarath.sasi@asx.com.au";
	public static final String CHESS = "CSP";
	public static final String ITE1 = "ITE1";
	public static final String TLS = "TLS";
	public static final String CERTIFICATE_REPLACED = "CR";
	public static final int BOUNCYCASTLE_VALUE = 92; //This value is used to remove the unwanted content for cert generation
	public ServiceAccountCredentialsSteps(ObjectContainer container) {
		super(container);
	}

	@Given("^an authorised user is on the Credentials table view page of a ([^\\\\\\\"]*)$")
	public void an_authorised_user_is_on_the_credentials_table_view_page_of_a_ciam_service_types(String displayName) throws InterruptedException {
		login();
		ServiceAccountPage serviceAccountPage = new ServiceAccountPage(super.driver);
		serviceAccountPage.searchServiceAccountByDisplayName(displayName).GotoCredentialsPage();
	}
	@Given("^An authorised user searches for a ([^\\\\\\\"]*)$")
	public void an_authorised_user_wants_to_add_Credentials(String displayName) throws InterruptedException {
		login();
		ServiceAccountPage serviceAccountPage = new ServiceAccountPage(super.driver);
		serviceAccountPage.searchServiceAccountByDisplayName(displayName);
	}
	@When("they view the CTA beside a credential with Expired or Revoking or Revoked")
	public void they_click_on_the_cta_beside_a_credential_with_revoking_expired_or_revoking_or_revoked() {
		assertTrue(new CredentialsPage(driver).verifyInCredentialsPage());
	}

	@Then("^they will not see an option called Download ASX Root Certificate for the ([^\\\\\\\"]*) mentioned$")
	public void they_will_not_see_an_option_called_download_asx_root_certificate(String status) {
		CredentialsPage credentialsPage = new CredentialsPage(driver);
		assertTrue(credentialsPage.isStatusDisplayed(status));
		assertEquals(0, credentialsPage.verifyNoShowMenuForStatus(status));
		logger.info("Test executed successfully");
	}
	@When("^I add a new credential$")
	public void i_cancel_the_creation_of_the_service_account(){
		CredentialsPage credentialsPagePageObject = new CredentialsPage(super.driver);
		credentialsPagePageObject.clickAddnewCredentialButton();
	}
	@Then("^I should see an option to upload a file$")
	public void i_should_see_an_option_to_upload_a_file(){
		FindElement findElementObject = new FindElement(super.driver);
		Assert.assertEquals(true, findElementObject.isElementDisplayed(CredentialsPage.getChooseFileButton()));
	}
	@When("^I upload a pem file$")
	public void i_upload_a_pem_file() throws IOException {
		CredentialsPage credentialsPagePageObject = new CredentialsPage(super.driver);
		credentialsPagePageObject.PasteCSRFileToField();
	}
	@Then("^I should see the encrypted certificate details$")
	public void i_should_see_the_encrypted_certificate_details(){
		CredentialsPage credentialsPagePageObject = new CredentialsPage(super.driver);
		String actualCSRValue = credentialsPagePageObject.getCSRTextAreaValue();

		boolean resultBeginCertificate = actualCSRValue.contains("BEGIN CERTIFICATE REQUEST");
		Assert.assertTrue(resultBeginCertificate);

		boolean resultEndCertificate = actualCSRValue.contains("END CERTIFICATE REQUEST");
		Assert.assertTrue(resultEndCertificate);
	}
	@When("^I confirm the creation of a new credential$")
	public void i_confirm_the_creation_of_a_new_credential(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.clickSubmitButton();
	}
	@Then("^The new credential should be generated$")
	public void i_should_see_the_new_credential(){
		FindElement findElementObject = new FindElement(super.driver);
		CredentialsPage credentialsPagePageObject = new CredentialsPage(super.driver);

		Assert.assertEquals(true, findElementObject.isElementDisplayed(CredentialsPage.getNewCredentialsGeneratedHeader()));
		credentialsPagePageObject.clickBackToServiceAccountCredentialsButton();
	}
	@When("^I add a new credential from the three dots menu$")
	public void i_add_a_new_credential_from_the_three_dots_menu(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.GotoCreateNewCredentialPage();
	}

	@Then("^I should see the CSR fields that need to be copied for ([^\\\\\\\"]*) and ([^\\\\\\\"]*)$")
	public void i_should_CSR_fields_that_need_to_be_copied(String ServiceAccountName, String ServiceAccountId){
		FindElement findElementObject = new FindElement(super.driver);
		String CSRFields = findElementObject.findElement(CredentialsPage.getcsrFieldsTextArea()).getText();
		Assert.assertTrue(CSRFields.contains("default_bits = 2048"));
		Assert.assertTrue(CSRFields.contains("prompt = no"));
		Assert.assertTrue(CSRFields.contains("default_md = sha256"));
		Assert.assertTrue(CSRFields.contains("distinguished_name = dn"));
		String CNString = "CN=" + ServiceAccountName;
		Assert.assertTrue(CSRFields.contains(CNString));
		String ServiceAccountIdString = "UID=" + ServiceAccountId;
		Assert.assertTrue(CSRFields.contains(ServiceAccountIdString));
	}

	@Given("^An authorised user creates a Service Account$")
	public void an_authorised_user_creates_a_service_account() throws InterruptedException {
		login();
		ServiceAccountPage serviceAccountPage = new ServiceAccountPage(driver);
		serviceAccountPage.clickNewServiceAccountButton()
				.enterServiceAccountDetails(serviceAccountName, serviceAccountName, EMAIL, CHESS, ITE1, TLS)
				.clickSubmitButton()
				.clickNavigateToServiceAccountListButton();
		Assert.assertEquals(true, serviceAccountPage.setDisplayNameFilterTextBox(serviceAccountName).clickSearchButtonWithWait()
				.getRowCellByDisplayNameIsDisplayed(serviceAccountName));
	}

	@Then("^I should see the CSR fields that need to be copied$")
	public void i_should_CSR_fields_that_need_to_be_copied(){
		FindElement findElementObject = new FindElement(super.driver);
		String CSRFields = findElementObject.findElement(CredentialsPage.getcsrFieldsTextArea()).getText();
		Assert.assertTrue(CSRFields.contains("default_bits = 2048"));
		Assert.assertTrue(CSRFields.contains("prompt = no"));
		Assert.assertTrue(CSRFields.contains("default_md = sha256"));
		Assert.assertTrue(CSRFields.contains("distinguished_name = dn"));
		String CNString = "CN=" + serviceAccountName;
		Assert.assertTrue(CSRFields.contains(CNString));

	}

	@Given("^an authorised user is on the Credentials table view page with ([^\\\\\\\"]*)$")
	public void and_authorised_user_is_on_the_credentials_table_view_page(String serviceType) throws InterruptedException, OperatorCreationException, NoSuchProviderException, NoSuchAlgorithmException, IOException {
		login();
		ServiceAccountPage serviceAccountPage = new ServiceAccountPage(driver);
		serviceAccountPage.clickNewServiceAccountButton()
				.enterServiceAccountDetails(serviceAccountName, serviceAccountName, EMAIL, CHESS, ITE1, serviceType)
				.clickSubmitButton()
				.clickNavigateToServiceAccountListButton();
		Assert.assertEquals(true, serviceAccountPage.setDisplayNameFilterTextBox(serviceAccountName).clickSearchButtonWithWait()
				.getRowCellByDisplayNameIsDisplayed(serviceAccountName));
		serviceAccountPage.GotoCreateNewCredentialPage().getDetailsForCSRGeneration();
		new CredentialsPage(driver).GenerateCSRUsingBouncyCastle(BOUNCYCASTLE_VALUE).clickSubmitButton().clickBackToServiceAccountCredentialsButton();
	}

	@When("they see a credential with status {string}")
	public void they_see_a_credential_with_status(String string) {
		Assert.assertEquals(true, new CredentialsPage(driver).isStatusDisplayed(string.toUpperCase()));
	}

	@Then("they will have the option to Download ASX Root Certificate")
	public void they_will_the_option_download_asx_root_certificate() {
		CredentialsPage credentialsPage = new CredentialsPage(driver);
		credentialsPage.clickCallToAction();
		Assert.assertTrue(credentialsPage.downloadCertificateDisplayed());
		Assert.assertTrue(credentialsPage.downloadRootCertificateDisplayed());
		credentialsPage.downloadCertificate();
		logger.info("Test executed successfully");
	}

	@Then("they will not have the option to Download ASX Root Certificate for status {string}")
	public void they_will_not_have_the_option_to_download_asx_root_certificate_for_status(String status) {
		assertEquals(0, new CredentialsPage(driver).verifyNoShowMenuForStatus(status));
		logger.info("Test executed successfully");
	}

	@When("changes the credential to status to {string}")
	public void changes_the_credential_to_status_to(String string) {
		CredentialsPage credentialsPage = new CredentialsPage(driver);
		credentialsPage.clickCallToAction().revokeCertificate(CERTIFICATE_REPLACED);
		Assert.assertEquals(true, credentialsPage.isStatusDisplayed(string.toUpperCase()));
	}

	@When("searches for the service account again after Revoking the credential")
	public void searches_for_the_service_account_again_after_revoking_the_credential() throws InterruptedException {
		ServiceAccountPage serviceAccountPage = new CredentialsPage(driver)
				.clickCallToAction().revokeCertificate(CERTIFICATE_REPLACED).clickBackToServiceAccount();
		Assert.assertEquals(true, serviceAccountPage.setDisplayNameFilterTextBox(serviceAccountName).clickSearchButtonWithWait()
				.getRowCellByDisplayNameIsDisplayed(serviceAccountName));
		serviceAccountPage.GotoCredentialsPage();
	}
}