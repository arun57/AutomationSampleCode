package com.dtaf.digital.model.pages;

import com.dtaf.digital.model.pages.csam.ViewAllUsersPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.dtaf.digital.model.components.dialogs.LoginDialog;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.function.Function;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * <h1>BasePage</h1>
 * <p>
 * {@code BasePage} is an abstract class which contains common page methods for
 * objects that are persistently present on most pages in the application. Page
 * objects that extend this class should ensure that the common methods are
 * executable within the page on the application.
 * </p>
 * 
 * <p>
 * <h2>Example</h2> <b>Navbars</b> are a good example of these objects as they
 * are usually visible/present on most pages in an application. The common
 * methods for this would be clicking on menu items to navigate to a
 * {@code new Page()}.
 * </p>
 * 
 * <h2>Note</h2>
 * <p>
 * If a page in the application cannot execute the common methods in this class,
 * do not extend this class on the page object. However if it is part of a group
 * of pages with similar methods, create a new abstract base page and extend
 * those page objects from there.
 * </p>
 */
public abstract class BasePage<T> {

	protected final WebDriver driver;

	public BasePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public BasePage clickManageUsers() {
		driver.findElement(By.xpath("//div[@data-target='#menu-manage-users']")).click();
		return this;
	}

	public String verifyManageUsersExists() {
		return driver.findElement(By.xpath("//div[@data-target='#menu-manage-users']/a")).getText();
	}

	public ViewAllUsersPage clickViewAllUsers() {
		driver.findElement(By.xpath("//*[@id='main-nav']//*[text()='View all users']")).click();
		return new ViewAllUsersPage(driver);
	}

	// Default page heading, needs to be overridden in each page
	public String lblPageHeading() {
		return driver.findElement(By.xpath("//*[contains(@class,'panel-header')]")).getText().toUpperCase();
	}

}
