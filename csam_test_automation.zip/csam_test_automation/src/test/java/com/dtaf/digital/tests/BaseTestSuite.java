package com.dtaf.digital.tests;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.openqa.selenium.WebDriver;

import com.dtaf.automation.driver.AbstractDriverFactory;
import com.dtaf.automation.driver.support.CustomWebDriverEventListener;
import com.dtaf.automation.environment.EnvironmentVariables;

import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * {@code BaseTestSuite} is an abstract class which contains common
 * methods for:
 * <ul>
 * 	<li>Setup of the test environment and logs</li>
 * 	<li>Clean up of test environment once completed</li>
 * 	<li>Other common methods that can be used for all tests</li>
 * </ul>
 * 
 * All tests for the project application must extend this class.
 * 
 * <p>
 * This class also contains a method for a cleaner
 * looking way to <b>open</b> page object classes.
 * </p>
 * 
 * <br>
 * <b>Example:</b>
 * <pre>
 * {@code
 * var message = open(HomePage.class).clickContactMenu()
 * 		.setContactData(contactData)
 * 		.clickSubmitButton()
 * 		.getSuccessMessage();
 * }
 * </pre>
 * 
 * @see EnvironmentVariables
 * @see AbstractDriverFactory
 * @see CustomWebDriverEventListener
 * @see AfterEachWebDriverProcessor
 */
@Execution(ExecutionMode.CONCURRENT)
public abstract class BaseTestSuite {

	protected WebDriver driver;

	@RegisterExtension
	AfterEachWebDriverProcessor webDriverProcessor = new AfterEachWebDriverProcessor();

	@BeforeEach
	public void setupTest(TestInfo testInfo) throws Exception {
		driver = new EventFiringWebDriver(
				new AbstractDriverFactory()
						.withHeadless(EnvironmentVariables.isHeadless())
						.withGridUrl(EnvironmentVariables.getGridUrl())
						.getInstance(EnvironmentVariables.getBrowser())
		).register(new CustomWebDriverEventListener(testInfo.getTestClass().get().getSimpleName(), testInfo.getTestMethod().get().getName()));
		driver.manage().timeouts().implicitlyWait(EnvironmentVariables.getImplicitWait(), TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(EnvironmentVariables.getUrl());
	}

	@AfterEach
	public void shutdownTest() {
		webDriverProcessor.setDriver(driver);
	}

	protected <T> T open(Class<T> clazz) {
        try {
            return clazz.getConstructor(WebDriver.class).newInstance(driver);
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | NoSuchMethodException | SecurityException e) {
            throw new RuntimeException(e);
        }
    }

}
