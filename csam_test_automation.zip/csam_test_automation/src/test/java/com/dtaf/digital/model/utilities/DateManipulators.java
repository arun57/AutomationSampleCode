package com.dtaf.digital.model.utilities;
//package com.dtaf.digital.model.utilities;

import java.time.Instant;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

public class DateManipulators {

	int numberOfDaysAhead;

	public int getNumberOfDaysAhead() {
		return numberOfDaysAhead;
	}

	public void setNumberOfDaysAhead(int numberOfDaysAhead) {
		this.numberOfDaysAhead = numberOfDaysAhead;
	}

	public void mFundDateManipulations(int days_ahead) {
		int days_to_add = 0;
		String day_of_the_week = Instant.now().atZone(ZoneId.of("Australia/Sydney")).getDayOfWeek().toString();
		switch (days_ahead) {
		case 1: // ("F");
			if (day_of_the_week == "FRIDAY") {
				days_to_add = days_to_add + 3;
			}
			if (day_of_the_week == "SATURDAY") {
				days_to_add = days_to_add + 2;
			}
			if (day_of_the_week == "SUNDAY") {
				days_to_add = days_to_add + 1;
			}
			setNumberOfDaysAhead(days_to_add);
			// Sat 2
			// Sun 1
			break;
		case 2: // ("TF");
			if (day_of_the_week == "FRIDAY" || day_of_the_week == "THURSDAY") {
				days_to_add = days_to_add + 4;
			}
			if (day_of_the_week == "SATURDAY") {
				days_to_add = days_to_add + 3;
			}
			if (day_of_the_week == "SUNDAY") {
				days_to_add = days_to_add + 2;
			}
			setNumberOfDaysAhead(days_to_add);
			// Sat 3
			// Sun 2
			break;
		case 3: // ("WTF");
			if (day_of_the_week == "FRIDAY" || day_of_the_week == "THURSDAY" || day_of_the_week == "WEDNESDAY") {
				days_to_add = days_to_add + 5;
			}
			if (day_of_the_week == "SATURDAY") {
				days_to_add = days_to_add + 4;
			}
			if (day_of_the_week == "SUNDAY") {
				days_to_add = days_to_add + 3;
			}
			setNumberOfDaysAhead(days_to_add);
			// Sat 4
			// Sun 3
			break;
		case 4: // ("TWTF");
			if (day_of_the_week == "FRIDAY" || day_of_the_week == "THURSDAY" || day_of_the_week == "WEDNESDAY"
					|| day_of_the_week == "TUESDAY") {
				days_to_add = days_to_add + 6;
			}
			if (day_of_the_week == "SATURDAY") {
				days_to_add = days_to_add + 5;
			}
			if (day_of_the_week == "SUNDAY") {
				days_to_add = days_to_add + 4;
			}
			setNumberOfDaysAhead(days_to_add);
			// Sat 5
			// Sun 4
			break;
		case 5: // ("MTWTF");
			if (day_of_the_week == "FRIDAY" || day_of_the_week == "THURSDAY" || day_of_the_week == "WEDNESDAY"
					|| day_of_the_week == "TUESDAY" || day_of_the_week == "MONDAY") {
				days_to_add = days_to_add + 7;
			}
			if (day_of_the_week == "SATURDAY") {
				days_to_add = days_to_add + 6;
			}
			if (day_of_the_week == "SUNDAY") {
				days_to_add = days_to_add + 5;
			}
			setNumberOfDaysAhead(days_to_add);
			// Sat 6
			// Sun 5
			break;
		case 7:
		case 14:
		case 49:
		case 98:
		case 343:
		case 686:
			if (day_of_the_week == "FRIDAY" || day_of_the_week == "THURSDAY" || day_of_the_week == "WEDNESDAY"
					|| day_of_the_week == "TUESDAY" || day_of_the_week == "MONDAY") {
				days_to_add = days_ahead + 7;
			}
			if (day_of_the_week == "SATURDAY") {
				days_to_add = days_ahead + 6;
			}
			if (day_of_the_week == "SUNDAY") {
				days_to_add = days_ahead + 5;
			}
			setNumberOfDaysAhead(days_to_add);
			// Sat 6
			// Sun 5
			break;
		}
	}

	public String ddidDateManipulator() {
		int daysAhead = getNumberOfDaysAhead();
		// Instant.now().atZone(ZoneId.systemDefault()).truncatedTo(ChronoUnit.MILLIS);
		String currentDate = Instant.now().atZone(ZoneId.of("Australia/Sydney")).truncatedTo(ChronoUnit.MILLIS)
				.plus(Period.ofDays(daysAhead)).toString();
		String ddidDate = currentDate.substring(0, 11) + currentDate.substring(11, 23).replaceAll("\\d", "0") + "Z";
		return ddidDate;
	}

	public String ddidDateZoneAdjustor(int days) {
		String currentDate = Instant.now().atZone(ZoneId.of("Australia/Sydney")).truncatedTo(ChronoUnit.MILLIS)
				.plus(Period.ofDays(days)).toString();
		String ddidDate = currentDate.substring(0, 11) + currentDate.substring(11, 23).replaceAll("\\d", "0") + "Z";
		return ddidDate;
	}

	public String ddidDateZoneAdjustorPast(int days) {
		String currentDate;
		String day_of_the_week = Instant.now().atZone(ZoneId.of("Australia/Sydney")).getDayOfWeek().toString();
		if (day_of_the_week == "MONDAY"){
			currentDate = Instant.now().atZone(ZoneId.of("Australia/Sydney")).truncatedTo(ChronoUnit.MILLIS)
					.minus(Period.ofDays(3)).toString();
		}
		else {
			currentDate = Instant.now().atZone(ZoneId.of("Australia/Sydney")).truncatedTo(ChronoUnit.MILLIS)
					.minus(Period.ofDays(days)).toString();
		}
		String ddidDate = currentDate.substring(0, 11) + currentDate.substring(11, 23).replaceAll("\\d", "0") + "Z";
		return ddidDate;
	}

	public String ddidDateZoneAdjustor() {
		String currentDate = Instant.now().atZone(ZoneId.of("Australia/Sydney")).truncatedTo(ChronoUnit.MILLIS).toString();
		String ddidDate = currentDate.substring(0, 11) + currentDate.substring(11, 23).replaceAll("\\d", "0") + "Z";
		return ddidDate;
	}

	public String ddiDate(int days_ahead) {
		mFundDateManipulations(days_ahead);
		return ddidDateManipulator();
	}
}
