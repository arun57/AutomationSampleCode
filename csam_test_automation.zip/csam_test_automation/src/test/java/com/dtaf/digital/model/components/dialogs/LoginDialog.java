package com.dtaf.digital.model.components.dialogs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.dtaf.digital.model.data.LoginData;

public class LoginDialog<T> {

	private WebElement element;
	private T parent;

	public LoginDialog(WebElement element, T parent) {
		this.element = element;
		this.parent = parent;
	}

	public LoginDialog<T> setUsername(String username) {
		element.findElement(By.id("idToken1")).sendKeys(username);
		return this;
	}

	public LoginDialog<T> setPassword(String password) {
		element.findElement(By.id("idToken2")).sendKeys(password);
		return this;
	}

	public T clickLoginButton() {
		element.findElement(By.name("callback_2")).click();
		return parent;
	}
	
	/*
	 * public LoginDialog<T> clickAgreeCheckbox() {
	 * element.findElement(By.id("agree")).click(); return this; }
	 */
	
	public T login(LoginData loginData) {
		return this.setUsername(loginData.username())
			.setPassword(loginData.password())
			//.clickAgreeCheckbox()
			.clickLoginButton();
	}

	public String getErrorMessage() {
		return element.findElement(By.id("login-error")).getText();
	}
}