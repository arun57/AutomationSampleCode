package com.dtaf.digital.model.api;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public abstract class BaseAPI {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());

    protected HttpUrl baseURL;
    protected OkHttpClient client;
    protected MediaType mediaType;
    protected Response rawResponse;
    private String responseBody;
    private HttpUrl.Builder httpBuilder;

    public BaseAPI(HttpUrl baseURL) {
        this.client = new OkHttpClient();
        this.httpBuilder=baseURL.newBuilder();
    }

    public String getResponseBody() throws IOException {
        if(responseBody == null) responseBody = rawResponse.body().string();
        return responseBody;
    }

    public Response getRawResponse() {
        return this.rawResponse;
    }

    public String get()
            throws IOException {
        return run(new Request.Builder().url(httpBuilder.build()).get().build());
    }

    public String post(String body)
            throws IOException {
        return run(new Request.Builder().url(httpBuilder.build()).post(RequestBody.create(mediaType, body)).build());
    }

    public String put(String body)
            throws IOException {
        return run(new Request.Builder().url(httpBuilder.build()).put(RequestBody.create(mediaType, body)).build());
    }

    public String delete(String body)
            throws IOException {
        return run(new Request.Builder().url(httpBuilder.build()).delete(RequestBody.create(mediaType, body)).build());
    }

    public String delete()
            throws IOException {
        return run(new Request.Builder().url(httpBuilder.build()).delete().build());
    }

    public BaseAPI withoutParams() {
        updateHttpBuilder(Arrays.asList(), Collections.emptyMap());
        return this;
    }

    public BaseAPI withPathSegments(List<String> pathSegments) {
        updateHttpBuilder(pathSegments, Collections.emptyMap());
        return this;
    }

    public BaseAPI withQueryParams(Map<String, String> queryParams) {
        updateHttpBuilder(Arrays.asList(), queryParams);
        return this;
    }

    private void updateHttpBuilder(List<String> positionParams, Map<String, String> queryParams) {        
        positionParams.forEach(p -> httpBuilder.addPathSegment(p));
        queryParams.forEach((k,v) -> httpBuilder.addQueryParameter(k,v)); 
    }

    protected void setResourceURL(String resourceURL) {
        if(resourceURL.startsWith("/")) 
                resourceURL = resourceURL.replaceFirst("\\/", "");
        this.httpBuilder.addPathSegment(resourceURL);
    }

    protected void setMediaType(String type) {
        this.mediaType = MediaType.get(type);
    }

    protected void setResponseBody(String body) {
        logger.info("Response body: {}",body);
        this.responseBody = body;
    }

    private String run(Request request) throws IOException {
        logger.info("Seding {} request to {}", request.method(), request.url().toString());
        rawResponse = client.newCall(request).execute();
        setResponseBody(rawResponse.body().string());
        return getResponseBody();
    }
}

