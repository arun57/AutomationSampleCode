package com.dtaf.digital.bdd.steps.hooks;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import com.dtaf.automation.driver.AbstractDriverFactory;
import com.dtaf.automation.driver.support.CustomWebDriverEventListener;
import com.dtaf.automation.environment.EnvironmentVariables;
import com.dtaf.digital.bdd.steps.support.ObjectContainer;

import org.openqa.selenium.TakesScreenshot;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class WebStepHooks {

	private ObjectContainer objectContainer;
	private final Logger logger = LoggerFactory.getLogger(WebStepHooks.class);

	public WebStepHooks(ObjectContainer objectContainer) {
		this.objectContainer = objectContainer;
	}

	@Before("@web")
	public void setup(Scenario scenario) throws Exception {
		WebDriver driver = new EventFiringWebDriver(
				new AbstractDriverFactory()
						.withHeadless(EnvironmentVariables.isHeadless())
						.withGridUrl(EnvironmentVariables.getGridUrl())
						.getInstance(EnvironmentVariables.getBrowser())
		).register(new CustomWebDriverEventListener(scenario.getClass().getName(), scenario.getName()));
		driver.manage().timeouts().implicitlyWait(EnvironmentVariables.getImplicitWait(), TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().window().fullscreen();
		driver.manage().window().setSize(new Dimension(1920,1080));
		driver.navigate().to(EnvironmentVariables.getUrl());

		this.objectContainer.setDriver(driver);
	}

	//Added for screenshots
//	@After("@web")
//	public void cleanup() {
//		objectContainer.getDriver().quit();
//	}
	
	@After("@web")
	public void cleanup(Scenario scenario ) {
		saveScreenshot(objectContainer.getDriver(),scenario.getName()+scenario.getStatus().name()
				+ DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now()));
		objectContainer.getDriver().quit();
	}
	
	private void saveScreenshot(WebDriver driver, String testname) {
		try {
			var screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			File destination = new File(System.getProperty("user.dir")
					+File.separator+"target"+File.separator
					+testname.replace("()", "")
					+".png");
			Files.move(screenshotFile.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
			logger.info(destination.getAbsolutePath());
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}
}
