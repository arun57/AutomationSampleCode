package com.dtaf.digital.bdd.steps.csam;

import com.dtaf.digital.bdd.steps.support.ObjectContainer;
import com.dtaf.digital.bdd.steps.support.WebBaseSteps;
import com.dtaf.digital.model.data.LoginData;
import com.dtaf.digital.model.pages.EnvironmentsPage;
import com.dtaf.digital.model.pages.HomePage;
import com.dtaf.digital.model.pages.SalesforceLoginPage;
import com.dtaf.digital.model.pages.csam.ServiceTypesPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ServiceManagementSteps extends WebBaseSteps {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());
    public static final String AUTOTEST = "AUTOTEST";
    public static final String SELENIUM_USERNAME = "SELENIUM_USERNAME";
    public static final String SELENIUM_SECRET = "SELENIUM_SECRET";
    private String inputDateTime;

    public ServiceManagementSteps(ObjectContainer container) {
        super(container);
    }

    @Given("an authorised Salesforce Administrator is logged onto the Salesforce Console")
    public void an_authorised_salesforce_administrator_is_logged_onto_the_salesforce_console() {
        container.register("login",
                new LoginData(System.getenv(SELENIUM_USERNAME), System.getenv(SELENIUM_SECRET)));
        LoginData loginData = container.retrieve("login");
        open(SalesforceLoginPage.class).login(loginData);
    }

    @And("^is on ([^\\\\\\\"]*) in Salesforce Admin Portal$")
    public void is_on_ciam_environments_in_salesforce_admin_portal(String tab) {
        HomePage homePage = new HomePage(driver);
        homePage.gotoMenu(tab);
    }

    @When("^the user clicks on the relevant ([^\\\\\\\"]*) they want to modify$")
    public void the_user_clicks_on_the_relevant_description_they_want_to_modify(String EnvironmentName) {
        EnvironmentsPage environmentsPage = new EnvironmentsPage(driver);
        environmentsPage.clickEnvironment(EnvironmentName);
    }

    @Then("the edit form for the chosen environment will be displayed")
    public void the_edit_form_for_the_chosen_environment_will_be_displayed() {
        EnvironmentsPage environmentsPage = new EnvironmentsPage(driver);
        assertTrue(environmentsPage.verifyLabelEnvironmentNameExists());
        assertTrue(environmentsPage.verifyEditEnvironmentNameEnabled());
        logger.info("Test CIAMP-3053 executed successfully");
    }

    @Given("^user navigates to ([^\\\\\\\\\\\\\\\"]*) with chosen environment displayed$")
    public void user_navigates_to_tab_with_chosen_environment_displayed(String tab) {
        container.register("login",
                new LoginData(System.getenv(SELENIUM_USERNAME), System.getenv(SELENIUM_SECRET)));
        LoginData loginData = container.retrieve("login");
        open(SalesforceLoginPage.class).login(loginData).gotoMenu(tab).clickEnvironment(AUTOTEST)
                .verifyLabelEnvironmentNameExists();
    }

    @When("the Salesforce Administrator save changes after modifying the display name")
    public void the_salesforce_administrator_save_changes_after_modifying_the_display_name() {
        inputDateTime = AUTOTEST + DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());
        EnvironmentsPage environmentsPage = new EnvironmentsPage(driver);
        environmentsPage.clickEditEnvironmentName().inputEnvironmentName(inputDateTime).clickSave();
    }

    @Then("the selected environment display name updated will be reflected")
    public void the_selected_environment_display_name_updated_will_be_reflected() {
        EnvironmentsPage environmentsPage = new EnvironmentsPage(driver);
        assertEquals(inputDateTime, environmentsPage.verifyEnvironmentName(AUTOTEST));
    }

    @Given("^user navigates to ([^\\\\\\\\\\\\\\\"]*) with chosen service type displayed$")
    public void user_navigates_to_ciam_service_types_with_chosen_service_type_displayed(String tab) {
        container.register("login",
                new LoginData(System.getenv(SELENIUM_USERNAME), System.getenv(SELENIUM_SECRET)));
        LoginData loginData = container.retrieve("login");
        open(SalesforceLoginPage.class).login(loginData).gotoMenuServiceType(tab).clickServiceType(AUTOTEST)
                .verifyLabelServiceTypeNameExists();
    }

    @When("the Salesforce Administrator save changes after modifying the service type")
    public void the_salesforce_administrator_save_changes_after_modifying_the_service_type() {
        inputDateTime = AUTOTEST + DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());
        ServiceTypesPage serviceTypesPage = new ServiceTypesPage(driver);
        serviceTypesPage.clickEditServiceTypeName().inputServiceTypeName(inputDateTime).clickSave();
    }

    @Then("the selected service type display name updated will be reflected")
    public void the_selected_service_type_display_name_updated_will_be_reflected() {
        ServiceTypesPage serviceTypesPage = new ServiceTypesPage(driver);
        assertEquals(inputDateTime, serviceTypesPage.verifyServiceTypeName(AUTOTEST));
    }
}
