package com.dtaf.digital.bdd.steps;

import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@Execution(ExecutionMode.CONCURRENT)
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" }, 
				features = { "src/test/resources/features" }
				 )
public class CucumberRunner {
	
}
