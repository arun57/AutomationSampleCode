package com.dtaf.digital.model.pages.csam;

import com.dtaf.digital.model.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.dtaf.digital.model.data.LoginData;

public class LoginPage extends BasePage<LoginPage> {
	
	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public LoginPage setUsername(String username) {
		driver.findElement(By.id("idToken1")).sendKeys(username);
		return this;
	}

	public LoginPage setPassword(String password) {
		driver.findElement(By.id("idToken2")).sendKeys(password);
		return this;
	}

	public void clickLoginButton() {
		driver.findElement(By.name("callback_2")).click();
	}
	
	/*
	 * public LoginDialog<T> clickAgreeCheckbox() {
	 * element.findElement(By.id("agree")).click(); return this; }
	 */
	
	
	public void login(LoginData loginData) {
		setUsername(loginData.username()).setPassword(loginData.password()).clickLoginButton();
	}
	 
	public String getErrorMessage() {
		return driver.findElement(By.className("message")).getText();
	}
}
