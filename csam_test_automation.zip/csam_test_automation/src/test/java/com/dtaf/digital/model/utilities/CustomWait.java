package com.dtaf.digital.model.utilities;

import com.dtaf.digital.model.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CustomWait extends BasePage<CustomWait> {

    public CustomWait(WebDriver driver) {
        super(driver);
    }

    public CustomWait waitElementToBeClickable(By element){
        new WebDriverWait(driver,10).
                until(ExpectedConditions.elementToBeClickable(driver.findElement(element)));
        return this;
    }

    public CustomWait waitElementToBeVisible(By element){
        new WebDriverWait(driver,10).
                until(ExpectedConditions.visibilityOf(driver.findElement(element)));
        return this;
    }

    public CustomWait shortWait() throws InterruptedException {
        Thread.sleep(2000);
        return this;
    }

    public CustomWait mediumWait() throws InterruptedException {
        Thread.sleep(5000);
        return this;
    }

    public CustomWait longWait() throws InterruptedException {
        Thread.sleep(10000);
        return this;
    }



}
