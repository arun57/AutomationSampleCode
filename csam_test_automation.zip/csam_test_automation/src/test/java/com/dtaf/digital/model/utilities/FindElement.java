package com.dtaf.digital.model.utilities;

import com.dtaf.digital.model.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class FindElement extends BasePage<FindElement> {

    public FindElement(WebDriver driver) {
        super(driver);
    }

    public WebElement findElement(By element){
        return driver.findElement(element);
    }

    public List<WebElement> findElements(By element){
        return driver.findElements(element);
    }

    public boolean isElementDisplayed(By elementLocator){
        WebElement element = driver.findElement(elementLocator);
        if(element.isDisplayed()){
            return true;
        }
        else{
            return false;
        }
    }
    public void selectDropdownoptionByValue(WebElement dropdown, String value){
        Select selectElement = new Select(dropdown);
        selectElement.selectByValue(value);
    }

}
