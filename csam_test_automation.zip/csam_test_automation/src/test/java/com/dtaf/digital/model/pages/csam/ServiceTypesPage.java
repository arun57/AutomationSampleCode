package com.dtaf.digital.model.pages.csam;

import com.dtaf.digital.model.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ServiceTypesPage extends BasePage<ServiceTypesPage> {

	public ServiceTypesPage(WebDriver driver) {
		super(driver);
	}

	public ServiceTypesPage clickServiceType(String input) {
		driver.findElement(By.xpath("//table//*[contains(text(),'" + input + "')]")).click();
		return this;
	}

	public boolean verifyLabelServiceTypeNameExists() {
		return !driver.findElements(By.xpath("//table//*[(text()='Service Type Name')]")).isEmpty();
	}

	public ServiceTypesPage clickEditServiceTypeName() {
		 driver.findElement(By.xpath("//*[@title='Edit Service Type Name']")).click();
		 return this;
	}

	public ServiceTypesPage inputServiceTypeName(String input) {
		WebElement element = driver.findElement(By.xpath("//*[@name='Name']")); //By.name not working
		element.clear();
		element.sendKeys(input);
		return this;
	}

	public ServiceTypesPage clickSave() {
		driver.findElement(By.xpath("//*[@name='SaveEdit']")).click();
		return this;
	}

	public String verifyServiceTypeName(String input) {
		return driver.findElement(By.xpath(
				"//div[@class='slds-form']//*[text()='Service Type Name']/parent::div/following-sibling::div//*[contains(text(),'"
						+ input + "')]"))
				.getText();
	}
}
