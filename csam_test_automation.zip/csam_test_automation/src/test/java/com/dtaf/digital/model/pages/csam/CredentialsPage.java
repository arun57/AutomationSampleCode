package com.dtaf.digital.model.pages.csam;

import com.dtaf.digital.model.pages.BasePage;
import com.dtaf.digital.model.utilities.FindElement;
import org.bouncycastle.openssl.PEMWriter;
import org.bouncycastle.util.io.pem.PemObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Security;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.pkcs.PKCS10CertificationRequestBuilder;
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.security.*;

public class CredentialsPage extends BasePage<CredentialsPage> {

	public CredentialsPage(WebDriver driver) {
		super(driver);
	}

	public FindElement searchElement = new FindElement(driver);
	protected final Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());
	public static By addNewCredentialButton = By.xpath("//button[contains(text(),'Add New Credential')]");
	public static By chooseFileButton = By.xpath("//input[@name = 'csrFile']");
	public static By csrTextArea = By.xpath("//label[contains(text(),'Certificate Signing Request')]/..//textarea");
	public static By newCredentialsGeneratedHeader = By.xpath("//h2[contains(text(),'New Credentials Generated')]");
	public static By backToServiceAccountCredentialsButton = By.xpath("//button[contains(text(),'Back to Service Account Credentials')]");
	public static By csrFieldsTextArea = By.xpath("//p[@class = 'preformatted']");

	public static By getAddNewCredentialButton() {
		return addNewCredentialButton;
	}

	public static By getChooseFileButton() {
		return chooseFileButton;
	}

	public static By getCSRTextArea() {
		return csrTextArea;
	}

	public static By getNewCredentialsGeneratedHeader() {
		return newCredentialsGeneratedHeader;
	}

	public static By geBackToServiceAccountCredentialsButton() {
		return backToServiceAccountCredentialsButton;
	}

	public static By getcsrFieldsTextArea() {
		return csrFieldsTextArea;
	}

	public CredentialsPage clickAddnewCredentialButton() {
		searchElement.findElement(getAddNewCredentialButton()).click();
		return this;
	}

	public CredentialsPage clickChooseFileButton() {
		searchElement.findElement(getChooseFileButton()).click();
		return this;
	}

	public CredentialsPage setCSRTextArea(String CSRContent) {
		WebElement csrTextAreaObject = searchElement.findElement(csrTextArea);
		csrTextAreaObject.sendKeys(CSRContent);
		return this;
	}

	public String getCSRTextAreaValue() {
		WebElement csrTextAreaObject = searchElement.findElement(csrTextArea);
		String actualValue = csrTextAreaObject.getAttribute("value");
		return actualValue;
	}

	public CredentialsPage clickBackToServiceAccountCredentialsButton() {
		searchElement.findElement(geBackToServiceAccountCredentialsButton()).click();
		return this;
	}

	public int verifyNoShowMenuForStatus(String status) {
		return driver.findElements(By.xpath("//*[text()='" + status.toUpperCase() + "']/parent::td/following-sibling::td/lightning-button-menu")).size();
	}

	public CredentialsPage clickActiveStatusShowMenu() {
		driver.findElement(By.xpath("//*[text()='ACTIVE']/parent::td/following-sibling::td//*[text()='Show menu']")).click();
		return this;
	}

	public Boolean verifyInCredentialsPage() {
		return !driver.findElements(By.xpath("//h1[text()='Credentials']")).isEmpty();
	}

	public Boolean isStatusDisplayed(String status) {
		return driver.findElement(By.xpath("//*[text()='" + status.toUpperCase() + "']")).isDisplayed();
	}

	public CredentialsPage PasteCSRFileToField() throws IOException {
		String content;
		String CSRFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\RahulTest5_text.txt";
		content = new String(Files.readAllBytes(Paths.get(CSRFilePath)));
		System.out.println(content);
		setCSRTextArea(content);
		return this;
	}

	public String getDetailsForCSRGeneration() {
		return driver.findElement(By.xpath("//*[@class='preformatted']")).getText();
	}

	public CredentialsPage clickSubmitButton() {
		driver.findElement(By.xpath("//*[@name='submitButton']")).click();
		return this;
	}

	public CredentialsPage GenerateCSRUsingBouncyCastle(int value) throws OperatorCreationException, NoSuchProviderException, NoSuchAlgorithmException, IOException {
		String dn = getDetailsForCSRGeneration().substring(value).replaceAll("\\r\\n|\\r|\\n", ", ");
		logger.info(dn);
		Security.addProvider(new BouncyCastleProvider());
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
		keyPairGenerator.initialize(2048);
		KeyPair pair = keyPairGenerator.generateKeyPair();
		PKCS10CertificationRequestBuilder p10Builder = new JcaPKCS10CertificationRequestBuilder(
				X500Name.getInstance(new X509Principal(dn)), pair.getPublic());
		JcaContentSignerBuilder csBuilder = new JcaContentSignerBuilder("SHA256withRSA");
		ContentSigner signer = csBuilder.build(pair.getPrivate());
		PKCS10CertificationRequest csr = p10Builder.build(signer);
		PemObject pemObject = new PemObject("CERTIFICATE REQUEST", csr.getEncoded());
		StringWriter str = new StringWriter();
		PEMWriter pemWriter = new PEMWriter(str);
		pemWriter.writeObject(pemObject);
		pemWriter.close();
		str.close();
		setCSRTextArea(str.toString());
		logger.info(String.valueOf(str));
		return this;
	}

	//SVG Code
	public CredentialsPage clickCallToAction() {
		driver.findElement(By.xpath("//*[local-name()='svg' and @data-key='threedots']")).click();
		return this;
	}

	public CredentialsPage clickRevoke() {
		driver.findElement(By.xpath("//*[text()='Revoke']")).click();
		return this;
	}

	public boolean downloadCertificateDisplayed() {
		return driver.findElement(By.xpath("//*[text()='Download Certificate']")).isDisplayed();
	}

	public boolean downloadRootCertificateDisplayed() {
		return driver.findElement(By.xpath("//*[text()='Download Root Certificate']")).isDisplayed();
	}

	public CredentialsPage downloadCertificate() {
		driver.findElement(By.xpath("//*[text()='Download Certificate']")).click();
		return this;
	}

	public CredentialsPage selectReasonForCredentialRevocation(String reason) {
		driver.findElement(By.xpath("//*[@role='listbox']/*[@data-value='"+reason+"']")).click();
		return this;
	}

	public CredentialsPage clickSelectReasonForCredentialRevocation() {
		driver.findElement(By.xpath("//*[@name='reason']")).click();
		return this;
	}

	public ServiceAccountPage clickBackToServiceAccount() {
		driver.findElement(By.xpath("//*[contains(text(),'Back to Service Accounts')]")).click();
		return new ServiceAccountPage(driver);
	}

	public CredentialsPage clickYesRevoke() {
		driver.findElement(By.xpath("//*[text()='Yes, Revoke']")).click();
		return this;
	}

	public CredentialsPage revokeCertificate(String reason) {
		clickRevoke().clickSelectReasonForCredentialRevocation().selectReasonForCredentialRevocation(reason).clickYesRevoke();
		return this;
	}

}

//	public CredentialsPage GenerateCSRUsingBouncyCastle2()  throws OperatorCreationException, NoSuchProviderException, NoSuchAlgorithmException, IOException {
//		String content = getDetailsForCSRGeneration();
//		System.out.println("File Content is: "+content);
//		System.out.println(content);
//		int index = content.lastIndexOf("]");
//		String subStringContent = content.substring(index+1, content.length());
//		Pattern LINE_SEP_PATTERN = Pattern.compile("\\R");
//		String[] lines = LINE_SEP_PATTERN.split(subStringContent);
//		String endResultString = "";
//		for(int i=1; i<= lines.length-1; i++){
//			endResultString = endResultString + lines[i]+ ", ";
//		}
//
//		int myindex = endResultString.lastIndexOf(", ");
//		String mySTring = endResultString.substring(0,myindex);
//		System.out.println("Final Expected String is: ");
//		System.out.println(mySTring);
//		Security.addProvider(new BouncyCastleProvider());
//		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
//		keyPairGenerator.initialize(2048);
//		KeyPair pair =  keyPairGenerator.generateKeyPair();
//		PKCS10CertificationRequestBuilder p10Builder = new JcaPKCS10CertificationRequestBuilder(
//				X500Name.getInstance(new X509Principal(mySTring)), pair.getPublic());
//		JcaContentSignerBuilder csBuilder = new JcaContentSignerBuilder("SHA256withRSA");
//		ContentSigner signer = csBuilder.build(pair.getPrivate());
//		PKCS10CertificationRequest csr = p10Builder.build(signer);
//		PemObject pemObject = new PemObject("CERTIFICATE REQUEST", csr.getEncoded());
//		StringWriter str = new StringWriter();
//		PEMWriter pemWriter = new PEMWriter(str);
//		pemWriter.writeObject(pemObject);
//		pemWriter.close();
//		str.close();
//		System.out.println(str);
//		setCSRTextArea(str.toString());
//		return this;
//	}

