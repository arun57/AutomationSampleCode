package com.dtaf.digital.bdd.steps.csam;

import com.dtaf.digital.bdd.steps.support.ObjectContainer;
import com.dtaf.digital.bdd.steps.support.WebBaseSteps;
import com.dtaf.digital.model.data.LoginData;
import com.dtaf.digital.model.pages.csam.ServiceAccountPage;
import com.dtaf.digital.model.pages.csam.LoginPage;
import com.dtaf.digital.model.pages.csam.ViewAllUsersPage;
import com.dtaf.digital.model.utilities.CustomWait;
import com.dtaf.digital.model.utilities.FindElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

public class ServiceAccountSteps extends WebBaseSteps {

	public ServiceAccountSteps(ObjectContainer container) {
		super(container);
	}
	private String displayNameString;
	public static final String SERVICE_ACCOUNTS = "Service Accounts";

	public void login() throws InterruptedException {
		container.register("login", new LoginData(System.getenv("SELENIUM_USERNAME"), System.getenv("SELENIUM_SECRET")));
		LoginData loginData = container.retrieve("login");
		open(LoginPage.class).login(loginData);

		CustomWait wait = new CustomWait(driver);
		wait.longWait();
	}
	@Given("an authorised EA has logged onto the participant portal")
	@Given("I am on the CSAM Home Page")
	@Given("An ASX Online Participant user with no active business realms apps opened")
	public void i_am_on_the_csam_home_page() throws InterruptedException {
		login();
	}

	@Given("I am on the Create New Service Account screen")
	public void i_am_on_the_create_new_service_account_screen() throws InterruptedException {

		login();

		CustomWait wait = new CustomWait(driver);
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.clickNewServiceAccountButton();
		wait.shortWait();
	}
	@When("^I enter ([^\\\\\\\"]*) that exceeds the maximum length of thirty five characters in the ([^\\\\\\\"]*)$")
	public void i_enter_value_that_exceeds_the_maximum_length_of_characters_in_the_field(String FieldValue, String FieldName) {

//		WebElement myField = null;
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);

		if(FieldName.compareToIgnoreCase("displayname") == 0)
		{
			serviceAccountPageObject.setDisplayNameTextbox(FieldValue);
		}

		if(FieldName.compareToIgnoreCase("description") == 0)
		{
			serviceAccountPageObject.setDescriptionTextbox(FieldValue);
		}
	}
	@Then("^The cursor will stop and not accept further characters entered in the field ([^\\\\\\\"]*)$")
	public void the_cursor_will_stop_and_not_accept_further_characters_entered(String FieldName) {

		String actualFieldValue = "";
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);

		if(FieldName.compareToIgnoreCase("displayname") == 0)
		{
			actualFieldValue = serviceAccountPageObject.getDisplayNameTextboxValue();
		}
		if(FieldName.compareToIgnoreCase("description") == 0)
		{

			actualFieldValue = serviceAccountPageObject.getDescriptionTextboxValue();
		}

		Assert.assertEquals("Field Value: ", "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789", actualFieldValue);

	}

	@When("^I cancel the creation of the Service Account$")
	public void i_cancel_the_creation_of_the_service_account(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.clickCancelButton();
	}

	@Then("^I should be shown options for confirmation and cancellation$")
	public void i_should_be_shown_options_for_confirmation_and_cancellation(){

		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		FindElement findElementObject = new FindElement(super.driver);

		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getYesCancelButton()));
		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getNoIWantToGoBackButton()));
	}
	@When("^I confirm the cancellation$")
	public void i_confirm_the_cancellation(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.clickYesCancelButton();
	}
	@Then("^I should navigate back to the Service Accounts Page$")
	public void i_should_navigate_back_to_the_Service_Accounts_Page(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		FindElement findElementObject = new FindElement(super.driver);

		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getNewServiceAccountButton()));
	}
	@When("^I deny the cancellation confirmation$")
	public void i_deny_the_cancellation_confirmation(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.clickNoIWantToGoBackButton();
	}
	@Then("^I should navigate back to the Service Account Creation Page$")
	public void i_should_navigate_back_to_the_Service_Account_Creation_Page(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		FindElement findElementObject = new FindElement(super.driver);

		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getDisplayNameTextbox()));
	}
	@Then("^I should see an option to create a New Service Account$")
	@Then("^They should see an option to create a New Service Account$")
	public void i_should_see_an_option_to_create_a_New_Service_Account(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		FindElement findElementObject = new FindElement(super.driver);

		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getNewServiceAccountButton()));
	}
	@When("^I enter empty value in ([^\\\\\\\"]*) field$")
	public void i_enter_empty_value_in_the_field(String FieldName){


		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);

		if(FieldName.compareToIgnoreCase("displayname") == 0)
		{
			serviceAccountPageObject.setDisplayNameTextbox("" + Keys.TAB);
		}
		if(FieldName.compareToIgnoreCase("description") == 0)
		{
			serviceAccountPageObject.setDescriptionTextbox(""+ Keys.TAB);
		}
	}
	@Then("^I should see a warning stating ([^\\\\\\\"]*) for the ([^\\\\\\\"]*)$")
	public void i_should_see_a_warning(String WarningText, String FieldName){

		FindElement findElementObject = new FindElement(super.driver);

		if(FieldName.compareToIgnoreCase("displayname") == 0)
		{
			Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getDisplayNameEmptyWarning()));
		}
		if(FieldName.compareToIgnoreCase("description") == 0)
		{
			Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getDescriptionEmptyWarning()));
		}
	}

	@When("^I submit the new service account from without any details filled$")
	public void i_submit_the_new_service_account_from_without_any_details_filled(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.clickSubmitButton();
	}
	@Then("^I should see warnings for mandatory fields$")
	public void i_should_see_warnings_for_mandatory_fields(){
		FindElement findElementObject = new FindElement(super.driver);
		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getEmailEmptyWarning()));
		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getServiceEmptyWarning()));
		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getEnvironmentEmptyWarning()));
		Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getServiceAccountEmptyWarning()));
	}
	@When("^I create a new Service Account with ([^\\\\\\\"]*),([^\\\\\\\"]*),([^\\\\\\\"]*),([^\\\\\\\"]*),([^\\\\\\\"]*),([^\\\\\\\"]*)$")
	public void i_create_service_account(String displayName, String description, String email, String service, String environment, String accountType){

		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		displayNameString = displayName + DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());

		serviceAccountPageObject.enterServiceAccountDetails(displayNameString,description,email,service,environment,accountType);
//		serviceAccountPageObject.clickSubmitButton();
//		serviceAccountPageObject.clickNavigateToServiceAccountListButton();
	}
	@Then("^A New Service Account should be created$")
	public void a_new_service_account_should_be_created(){
		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);
		serviceAccountPageObject.searchServiceAccountByDisplayName(displayNameString);

		Assert.assertEquals(true, serviceAccountPageObject.getRowCellByDisplayName(displayNameString).isDisplayed());
	}
	@When("^I create a new Service Account with duplicate name ([^\\\\\\\"]*)$")
	public void i_create_service_account_with_duplicate_name(String duplicateName){

		ServiceAccountPage serviceAccountPageObject = new ServiceAccountPage(super.driver);


		serviceAccountPageObject.enterServiceAccountDetails(duplicateName,"AutoTestAccount","rahul.hartalkar@asx.com.au","CSP","ITE2","TLS");
		serviceAccountPageObject.clickSubmitButton();

	}
	@Then("^I should see an error for the Duplicate Display Name$")
	public void i_should_see_an_error_for_the_duplicate_display_name(){
		FindElement findElementObject = new FindElement(super.driver);

			Assert.assertEquals(true, findElementObject.isElementDisplayed(ServiceAccountPage.getDisplayNameDuplicateWarning()));
	}

	@When("they have successfully logged on")
	public void they_have_successfully_logged_on() {
		Assert.assertEquals(SERVICE_ACCOUNTS.toUpperCase(), open(ServiceAccountPage.class).lblPageHeading());
	}

}