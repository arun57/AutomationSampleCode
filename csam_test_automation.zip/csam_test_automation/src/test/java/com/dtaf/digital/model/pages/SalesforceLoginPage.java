package com.dtaf.digital.model.pages;

import com.dtaf.digital.model.data.LoginData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SalesforceLoginPage extends BasePage<SalesforceLoginPage> {

	public SalesforceLoginPage(WebDriver driver) {
		super(driver);
	}

	public SalesforceLoginPage setUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
		return this;
	}

	public SalesforceLoginPage setPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}

	public void clickLoginButton() {
		driver.findElement(By.name("Login")).click();
	}

	public HomePage login(LoginData loginData) {
		setUsername(loginData.username()).setPassword(loginData.password()).clickLoginButton();
		return new HomePage(driver);
	}

	public String getErrorMessage() {
		return driver.findElement(By.className("error")).getText();
	}
}
