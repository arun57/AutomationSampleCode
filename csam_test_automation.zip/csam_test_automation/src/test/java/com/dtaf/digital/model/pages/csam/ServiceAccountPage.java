package com.dtaf.digital.model.pages.csam;

import com.dtaf.digital.model.pages.BasePage;
import com.dtaf.digital.model.pages.SalesforceLoginPage;
import com.dtaf.digital.model.utilities.CustomWait;
import com.dtaf.digital.model.utilities.FindElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class ServiceAccountPage extends BasePage<ServiceAccountPage> {

	public ServiceAccountPage(WebDriver driver) {
		super(driver);
	}
	public CustomWait wait = new CustomWait(driver);
	public FindElement searchElement = new FindElement(driver);

	private static By newServiceAccountButton = By.xpath("//button[contains(text(),'New Service Account')]");
	private static By displayNameTextbox = By.xpath("//input[@name = 'displayname']");
	private static By descriptionTextbox = By.xpath("//input[@name = 'description']");
	private static By cancelButton = By.xpath("//button[contains(text(),'Cancel')]");
	private static By yesCancelButton = By.xpath("//button[contains(text(),'Yes, Cancel')]");
	private static By noIWantToGoBackButton = By.xpath("//button[contains(text(),'No, I want to go back')]");
	private static By displayNameEmptyWarning = By.xpath("//span[contains(text(),'Please enter a Display name')]");
	private static By descriptionEmptyWarning = By.xpath("//span[contains(text(),'Please enter a Description')]");
	private static By emailEmptyWarning = By.xpath("//span[contains(text(),'Please enter a valid email address')]");
	private static By serviceEmptyWarning = By.xpath("//span[contains(text(),'Please select a Service')]");
	private static By environmentEmptyWarning = By.xpath("//span[contains(text(),'Please select an Environment')]");
	private static By serviceAccountEmptyWarning = By.xpath("//span[contains(text(),'Please select a Service account type')]");
	private static By submitButton = By.xpath("//button[contains(text(),'Submit')]");
	private static By emailTextbox = By.xpath("//input[@name = 'notificationemail']");
	private static By serviceDropdown = By.xpath("//select[@id = 'service-0']");
	private static By environmentDropdown = By.xpath("//select[@id = 'environment-0']");
	private static By serviceAccounttypeDropdown = By.xpath("//select[@id = 'r_type-0']");
	public static By displayNameFilter = By.xpath("//input[contains(@id, 'displayname-')]");
	private static By searchButton = By.xpath("(//button[contains(text(),'Search')])[2]");
	private static By navigateToServiceAccountListButton = By.xpath("//button[contains(text(),'Navigate to Service Account list')]");
	private static By displayNameDuplicateWarning = By.xpath("//span[contains(text(),'The Display Name already exists, please re-enter')]");

	public static By getNewServiceAccountButton() {
		return newServiceAccountButton;
	}
	public static By getDisplayNameTextbox() {
		return displayNameTextbox;
	}
	public static By getDescriptionTextbox() {
		return descriptionTextbox;
	}
	public static By getCancelButton() {
		return cancelButton;
	}
	public static By getYesCancelButton() {
		return yesCancelButton;
	}
	public static By getNoIWantToGoBackButton() {
		return noIWantToGoBackButton;
	}
	public static By getDisplayNameEmptyWarning() {
		return displayNameEmptyWarning;
	}
	public static By getDescriptionEmptyWarning() {
		return descriptionEmptyWarning;
	}
	public static By getEmailEmptyWarning() {
		return emailEmptyWarning;
	}
	public static By getServiceEmptyWarning() {
		return serviceEmptyWarning;
	}
	public static By getEnvironmentEmptyWarning() {
		return environmentEmptyWarning;
	}
	public static By getServiceAccountEmptyWarning() {
		return serviceAccountEmptyWarning;
	}
	public static By getSubmitButton() {
		return submitButton;
	}
	public static By getEmailTextbox() {
		return emailTextbox;
	}
	public static By getSearchButton() {
		return searchButton;
	}
	public static By getDisplayNameDuplicateWarning() {
		return displayNameDuplicateWarning;
	}

	public  WebElement getServiceDropdown(){
		WebElement serviceDropdownObject =  searchElement.findElement(serviceDropdown);
		return serviceDropdownObject;
	}
	public  WebElement getEnvironmentDropdown(){
		WebElement environmentDropdownObject =  searchElement.findElement(environmentDropdown);
		return environmentDropdownObject;
	}
	public  WebElement getServiceAccounttypeDropdown(){
		WebElement serviceAccounttypeDropdownnObject =  searchElement.findElement(serviceAccounttypeDropdown);
		return serviceAccounttypeDropdownnObject;
	}
	public WebElement getDisplayNameFilter(){
		WebElement displayNameFilterObject =  searchElement.findElement(displayNameFilter);
		return displayNameFilterObject;
	}
	public static By getNavigateToServiceAccountListButton() {
		return navigateToServiceAccountListButton;
	}

	public ServiceAccountPage clickNewServiceAccountButton() {
		searchElement.findElement(getNewServiceAccountButton()).click();
		return this;
	}
	public ServiceAccountPage clickCancelButton() {
		searchElement.findElement(getCancelButton()).click();
		return this;
	}
	public ServiceAccountPage clickYesCancelButton() {
		searchElement.findElement(getYesCancelButton()).click();
		return this;
	}
	public ServiceAccountPage clickNoIWantToGoBackButton() {
		searchElement.findElement(getNoIWantToGoBackButton()).click();
		return this;
	}
	public ServiceAccountPage setDisplayNameTextbox(String textvalue)  {
		WebElement myField = (WebElement)searchElement.findElement(getDisplayNameTextbox());
		myField.sendKeys(textvalue);
		return this;
	}
	public String getDisplayNameTextboxValue()  {
		WebElement myField = (WebElement)searchElement.findElement(getDisplayNameTextbox());
		String actualValue = myField.getAttribute("value");
		return actualValue;
	}
	public ServiceAccountPage setDescriptionTextbox(String textvalue)  {
		WebElement myField = (WebElement)searchElement.findElement(getDescriptionTextbox());
		myField.sendKeys(textvalue);
		return this;
	}
	public String getDescriptionTextboxValue()  {
		WebElement myField = (WebElement)searchElement.findElement(getDescriptionTextbox());
		String actualValue = myField.getAttribute("value");
		return actualValue;
	}
	public ServiceAccountPage clickSubmitButton() {
		searchElement.findElement(getSubmitButton()).click();
		return this;
	}
	public ServiceAccountPage setEmailTextbox(String textvalue)  {
		WebElement myField = (WebElement)searchElement.findElement(getEmailTextbox());
		myField.sendKeys(textvalue);
		return this;
	}
	public ServiceAccountPage setDisplayNameFilterTextBox(String textvalue)  {
		WebElement myField = getDisplayNameFilter();
		myField.sendKeys(textvalue);
		return this;
	}
	public ServiceAccountPage clickSearchButton() {
		searchElement.findElement(getSearchButton()).click();
		return this;
	}
	public ServiceAccountPage enterServiceAccountDetails(String displayName, String description, String email, String service, String environment, String accountType){

		setDisplayNameTextbox(displayName);
		setDescriptionTextbox(description);
		setEmailTextbox(email);
		searchElement.selectDropdownoptionByValue(getServiceDropdown(), service);
		searchElement.selectDropdownoptionByValue(getEnvironmentDropdown(), environment);
		searchElement.selectDropdownoptionByValue(getServiceAccounttypeDropdown(), accountType);
		return this;
	}

	public ServiceAccountPage searchServiceAccountByDisplayName(String displayName){
		setDisplayNameFilterTextBox(displayName);
		clickSearchButton();
		return this;
	}
	public ServiceAccountPage clickNavigateToServiceAccountListButton() {
		searchElement.findElement(getNavigateToServiceAccountListButton()).click();
		return this;
	}
	public WebElement getRowCellByDisplayName(String displayName){
		WebElement rowCell = null;
		String xpathString = "//div[contains(text(),'" + displayName + "')]";
		 rowCell = driver.findElement(By.xpath(xpathString));
		 return rowCell;
	}
	//Added isDispalyed here
	public boolean getRowCellByDisplayNameIsDisplayed(String displayName){
		return getRowCellByDisplayName(displayName).isDisplayed();
	}

	public ServiceAccountPage uploadFile()  {

		try {

			StringSelection ss = new StringSelection("C:\\TestData\\HelloWorld.pdf");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
		return this;
	}

	//SVG Code
	public ServiceAccountPage clickCallToAction() {
		driver.findElement(By.xpath("//*[local-name()='svg' and @data-key='threedots']")).click();
		return this;
	}

	public CredentialsPage clickViewCredentials() {
		driver.findElement(By.xpath("//*[text()='View Credentials']")).click();
		return new CredentialsPage(driver);
	}

	public CredentialsPage GotoCredentialsPage() {
		return clickCallToAction().clickViewCredentials();
	}
	public CredentialsPage clickCreateNewCredentials() {
		driver.findElement(By.xpath("//*[text()='Create New Credential']")).click();
		return new CredentialsPage(driver);
	}
	public CredentialsPage GotoCreateNewCredentialPage() {
		return clickCallToAction().clickCreateNewCredentials();
	}

	public ServiceAccountPage clickSearchButtonWithWait() throws InterruptedException {
		WebElement btnSearch = driver.findElement(By.xpath("(//button[contains(text(),'Search')])[2]"));
		wait.shortWait();
		//fluentWait(btnSearch);
		btnSearch.click();
		return this;
	}
}