package com.dtaf.digital.bdd.steps.support;

import java.lang.reflect.InvocationTargetException;

import com.dtaf.digital.model.data.LoginData;
import com.dtaf.digital.model.pages.csam.LoginPage;
import com.dtaf.digital.model.utilities.CustomWait;
import org.openqa.selenium.WebDriver;

public abstract class WebBaseSteps extends BaseSteps {

	protected WebDriver driver;

	public WebBaseSteps(ObjectContainer container) {
		super(container);
		this.driver = container.getDriver();
	}

	protected <T> T open(Class<T> clazz) {
        try {
            return clazz.getConstructor(WebDriver.class).newInstance(driver);
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | NoSuchMethodException | SecurityException e) {
            throw new RuntimeException(e);
        }
    }

    public void login() throws InterruptedException {
        container.register("login", new LoginData(System.getenv("SELENIUM_USERNAME"), System.getenv("SELENIUM_SECRET")));
        LoginData loginData = container.retrieve("login");
        open(LoginPage.class).login(loginData);
        CustomWait wait = new CustomWait(driver);
        wait.longWait();
    }
}
