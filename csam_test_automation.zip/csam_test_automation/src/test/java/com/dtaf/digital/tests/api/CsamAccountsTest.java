package com.dtaf.digital.tests.api;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.Matchers.equalTo;

@Tag("api")
public class CsamAccountsTest extends BaseAPITests{

	public static final String INSTANCE_URL = System.getenv("INSTANCE_URL");
	public static final String ITE1 = "\"Name\":\"ITE1 (Non Production)\"";
	public static final String ITE2 = "\"Name\":\"ITE2 (Non Production)\"";
	public static final String CHESS = "\"Name\":\"CHESS\"";
	public static final String ISO_20022_SIGNING = "\"Name\":\"ISO 20022 Signing\"";
	public static final String LEDGER_API_USER = "\"Name\":\"Ledger API User\"";
	public static final String TLS = "\"Name\":\"TLS\"";
	public static final String PROXY_HOST = "proxy.asx.com.au";
	public static final int PROXY_PORT = 8083;

//	The below code wil be used for test data setup in the future
//	public static final String CBA = "COMMONWEALTH BANK OF AUSTRALIA";
//
//	@Tag("csamAccounts")
//	@Tag("ciamp-3041")
//	@ParameterizedTest
//	@ValueSource(strings = {"SELECT+name+from+Account"})
//	public void ciamp_3041_csam_accounts_all(String params) {
//		 				given()
//							.auth().oauth2(access_token)
//							.contentType(ContentType.JSON)
//							.urlEncodingEnabled(false)
//							.proxy("proxy.asx.com.au", 8083)
//							.relaxedHTTPSValidation()
//							.queryParam("q", params).log().all()
//						.when()
//							.get(INSTANCE_URL)
//						.then()
//							.assertThat()
//							.statusCode(200).log().all()
//							.header("Content-Type", equalTo("application/json;charset=UTF-8"))
//							.body("done", equalTo(true))
//							.body(containsString(CBA));
//	}

	@Tag("csamEnvironments")
	@Tag("ciamp-2825")
	@ParameterizedTest
	@ValueSource(strings = {"SELECT+Name,IsActive__c,ExternalId__c,Service__c+FROM+CIAMEnvironment__c"})
	public void ciamp_2825_csam_environments_all(String params) {
						given()
							.auth().oauth2(access_token)
							.contentType(ContentType.JSON)
							.urlEncodingEnabled(false)
							.proxy(PROXY_HOST, PROXY_PORT)
							.relaxedHTTPSValidation()
							.queryParam("q", params).log().all()
						.when()
							.get(INSTANCE_URL)
						.then()
							.assertThat()
				 			.statusCode(200).log().all()
							.header("Content-Type", equalTo("application/json;charset=UTF-8"))
							.body("done", equalTo(true))
				 			.body(containsString(ITE1));
						//.body(containsString(ITE2)); commented as not for this release
	}

	@Tag("csamServices")
	@Tag("ciamp-2824")
	@ParameterizedTest
	@ValueSource(strings = {"SELECT+Name+FROM+CIAMService__c"})
	public void ciamp_2824_csam_services_all(String params) {
						given()
							.auth().oauth2(access_token)
							.contentType(ContentType.JSON)
							.urlEncodingEnabled(false)
							.proxy(PROXY_HOST, PROXY_PORT)
							.relaxedHTTPSValidation()
							.queryParam("q", params).log().all()
						.when()
							.get(INSTANCE_URL)
						.then()
							.assertThat()
							.statusCode(200).log().all()
							.header("Content-Type", equalTo("application/json;charset=UTF-8"))
							.body("done", equalTo(true))
							.body(containsString(CHESS));
	}

	@Tag("csamServiceTypes")
	@Tag("ciamp-2828")
	@ParameterizedTest
	@ValueSource(strings = {"SELECT+Name+FROM+CIAMServiceType__c"})
	public void ciamp_2828_csam_services_all(String params) {
						given()
							.auth().oauth2(access_token)
							.contentType(ContentType.JSON)
							.urlEncodingEnabled(false)
							.proxy(PROXY_HOST, PROXY_PORT)
							.relaxedHTTPSValidation()
							.queryParam("q", params).log().all()
						.when()
							.get(INSTANCE_URL)
						.then()
							.assertThat()
							.statusCode(200).log().all()
							.header("Content-Type", equalTo("application/json;charset=UTF-8"))
							.body("done", equalTo(true))
							.body(containsString(ISO_20022_SIGNING))
							.body(containsString(LEDGER_API_USER))
							.body(containsString(TLS));
	}
}

