package com.dtaf.digital.tests.api;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeEach;

import okhttp3.HttpUrl;

import static io.restassured.RestAssured.given;

public class BaseAPITests {

    private static final String TOKEN_URL = System.getenv("TOKEN_URL");
    private static final String CLIENT_ID = System.getenv("CLIENT_ID");
    private static final String CLIENT_SECRET = System.getenv("CLIENT_SECRET");
    private static final String API_USERNAME = System.getenv("API_USERNAME");
    private static final String API_TOKEN = System.getenv("API_TOKEN");
    private static final String API_GRANT = "password";
    protected static String access_token;

    @BeforeEach
    public void setup() {
        access_token = given()
                    .queryParam("client_id", CLIENT_ID)
                    .queryParam("client_secret", CLIENT_SECRET)
                    .queryParam("username", API_USERNAME)
                    .queryParam("password", API_TOKEN)
                    .queryParam("grant_type", API_GRANT)
                    .contentType(ContentType.JSON)
                    .urlEncodingEnabled(false)
                    .proxy("proxy.asx.com.au", 8083)
                    .relaxedHTTPSValidation()
                .when()
                    .post(TOKEN_URL)
                .then()
                    .statusCode(200).extract().path("access_token").toString();
    }
}
