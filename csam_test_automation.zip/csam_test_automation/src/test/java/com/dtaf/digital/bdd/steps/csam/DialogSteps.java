package com.dtaf.digital.bdd.steps.csam;

import com.dtaf.digital.bdd.steps.support.ObjectContainer;
import com.dtaf.digital.bdd.steps.support.WebBaseSteps;
import com.dtaf.digital.model.pages.csam.DialogPage;
import com.dtaf.digital.model.pages.csam.ViewAllUsersPage;
import io.cucumber.java.en.Then;
import org.junit.Assert;

public class DialogSteps extends WebBaseSteps {

	public DialogSteps(ObjectContainer container) {
		super(container);
	}

	public static final String VIEW_ALL_USERS = "View All Users";
	public static final String MANAGE_USERS = "Manage Users";

	@Then("they will see Manage Users menu on the left hand pane")
	public void they_will_see_manage_users_menu_on_the_left_hand_pane() {
		var dialogPage = open(DialogPage.class);
		Assert.assertEquals(MANAGE_USERS, dialogPage.verifyManageUsersExists().trim());
		dialogPage.clickManageUsers().clickViewAllUsers();
	}

	@Then("can View All users for the selected account")
	public void can_view_all_users_for_the_selected_account() {
		Assert.assertEquals(VIEW_ALL_USERS.toUpperCase(), open(ViewAllUsersPage.class).lblPageHeading());
	}
}