package com.dtaf.digital.model.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EnvironmentsPage extends BasePage<EnvironmentsPage> {

	public EnvironmentsPage(WebDriver driver) {
		super(driver);
	}

	public EnvironmentsPage clickEnvironment(String input) {
		driver.findElement(By.xpath("//table//*[contains(text(),'" + input + "')]")).click();
		return this;
	}

	public boolean verifyLabelEnvironmentNameExists() {
		return !driver.findElements(By.xpath("//table//*[(text()='Environment Name')]")).isEmpty();
	}

	public boolean verifyEditEnvironmentNameEnabled() {
		return driver.findElement(By.xpath("//*[@title='Edit Environment Name']")).isEnabled();
	}

	public EnvironmentsPage clickEditEnvironmentName() {
		 driver.findElement(By.xpath("//*[@title='Edit Environment Name']")).click();
		 return this;
	}

	public EnvironmentsPage inputEnvironmentName(String input) {
		WebElement element = driver.findElement(By.xpath("//*[@name='Name']")); //By.name not working
		element.clear();
		element.sendKeys(input);
		return this;
	}

	public EnvironmentsPage clickSave() {
		driver.findElement(By.xpath("//*[@name='SaveEdit']")).click();
		return this;
	}

	public String verifyEnvironmentName(String input) {
		return driver.findElement(By.xpath(
				"//div[@class='slds-form']//*[text()='Environment Name']/parent::div/following-sibling::div//*[contains(text(),'"
						+ input + "')]"))
				.getText();
	}
}
