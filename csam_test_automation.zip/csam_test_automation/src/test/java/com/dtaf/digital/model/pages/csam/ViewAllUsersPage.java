package com.dtaf.digital.model.pages.csam;

import com.dtaf.digital.model.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ViewAllUsersPage extends BasePage<ViewAllUsersPage> {

	public ViewAllUsersPage(WebDriver driver) {
		super(driver);
	}
	
	public String lblPageHeading() {
		return driver.findElement(By.xpath("//*[@class='panel-header panel-icon icon-user']")).getText();
	}

}
